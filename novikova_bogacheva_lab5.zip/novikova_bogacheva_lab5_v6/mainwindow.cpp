#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

QList <QString> last_names;
QList <QString> numbers;
QMap <QString, QString> phone;

void MainWindow::on_pushButton_clicked()
{
    QString res = "фамилии в тел. книге: ";
    QString last_name = ui -> textEdit -> toPlainText();
    last_names.append(last_name);
    for (int i = 0; i < last_names.length(); i++)
    {
        res += last_names[i] + "; ";
    }
    ui -> textEdit_3 -> setText(res);
}


void MainWindow::on_pushButton_2_clicked()
{
    QString res = "номера в тел. книге: ";
    QString number = ui -> textEdit_2 -> toPlainText();
    numbers.append(number);
    for (int i = 0; i < numbers.length(); i++)
    {
        res += numbers[i] + "; ";
    }
    ui -> textEdit_3 -> setText(res);
}


void MainWindow::on_pushButton_3_clicked()
{
    if (last_names.length() == numbers.length())
    {
        for (int i = 0; i < last_names.length(); i++)
        {
            phone.insert(last_names[i], numbers[i]);
        }
    }
    else
    {
        ui -> textEdit_3 -> setText("длина книг не совпадает!! невозможно объединить");
    }

    QString res = "содержимое тел. книги:\n";
    QMap <QString, QString>::iterator it = phone.begin();
    for (;it != phone.end(); it++)
    {
        res += "фамилия: " + it.key() + "; номер телефона: " + it.value() + ":\n";
    }
    ui -> textEdit_3 -> setText(res);
}


void MainWindow::on_pushButton_4_clicked()
{
    last_names.clear();
    numbers.clear();
    phone.clear();
    ui -> textEdit_3 -> setText("все книги были очищены!!");
}

