#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString list = ui->lineEdit->text().trimmed();  // Удаляем лишние пробелы
    if (list.isEmpty()) {
        ui->label->setText("Ошибка: введите список чисел через пробел");
        return;
    }

    QStringList split = list.split(" ", Qt::SkipEmptyParts);  // Игнорируем пустые элементы
    QString res;

    for (int i = split.size() - 1; i >= 0; i--)
    {
        res = res + split[i] + " ";
    }

    ui->label->setText(res);
}
