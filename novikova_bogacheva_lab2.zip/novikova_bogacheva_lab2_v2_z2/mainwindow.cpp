#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>  // Для отладки

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    QString list = ui->textEdit->toPlainText();
    QStringList rows = list.split("\n");
    QVector<QVector<int>> matrix;
    bool inputIsValid = true;

    // Обработка ввода
    for (int j = 0; j < rows.length(); j++)
    {
        QStringList lines = rows[j].split(" ");
        QVector<int> numbers;
        for (int i = 0; i < lines.length(); i++)
        {
            bool ok;
            int temp = lines[i].toInt(&ok);
            if (!ok) {
                inputIsValid = false;
                break;
            }
            numbers.append(temp);
        }
        if (!inputIsValid) break;
        matrix.append(numbers);
    }

    // Если ввод некорректен
    if (!inputIsValid) {
        ui->label->setText("ошибка! введите только числа, разделённые пробелами и строками");
        ui->label_2->clear();
        return;
    }


    int odd = 0;
    int even = 0;

    for (int i = 0; i < matrix.size(); i += 2)
    {
        for (int j = 0; j < matrix[i].size(); j++)
        {
            odd += matrix[i][j];
        }
    }

    for (int i = 1; i < matrix.size(); i += 2)
    {
        for (int j = 0; j < matrix[i].size(); j++)
        {
            even += matrix[i][j];
        }
    }

    // Вывод результатов
    ui->label->setText("сумма нечётных строк матрицы равна: " + QString::number(odd));
    ui->label_2->setText("сумма чётных строк матрицы равна: " + QString::number(even));
}
