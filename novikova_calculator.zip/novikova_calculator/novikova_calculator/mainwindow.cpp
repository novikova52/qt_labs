#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <cmath>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}
QString yravnenie;
QString yravnenie_output;
QStringList sps;
QStringList yravnenie_output_sps;
void MainWindow::on_equals_clicked()
{
    sps = yravnenie.split(" ");
    int length = sps.length();
    int i = 1;
    if (sps.contains("*") || sps.contains("/"))
    {
        while (i<length)
        {
            if(i<length && sps[i] == "*")
            {
                sps.replace(i, QString::number(sps[i-1].toDouble() * sps[i+1].toDouble()));
                sps.removeAt(i-1);
                sps.removeAt(i);
                i = 1;
                length = sps.length();
                continue;
            }
            if(i<length && sps[i] == "/")
            {
                sps.replace(i, QString::number(sps[i-1].toDouble() / sps[i+1].toDouble()));
                sps.removeAt(i-1);
                sps.removeAt(i);
                i = 1;
                length = sps.length();
                continue;
            }
            length = sps.length();
            i += 1;
        }
    }
    i = 0;
    length = sps.length();
    for (int i = 0; i<length/2; i++)
    {
        if(sps[1] == "+")
        {
            sps.replace(1, QString::number(sps[0].toDouble() + sps[2].toDouble()));
            sps.removeAt(2);
            sps.removeAt(0);
            continue;
        }
        if(sps[1] == "-")
        {
            sps.replace(1, QString::number(sps[0].toDouble() - sps[2].toDouble()));
            sps.removeAt(2);
            sps.removeAt(0);
            continue;
        }
    }
    ui -> output -> setText(sps.join(" "));
}

void MainWindow::on_odin_clicked()
{
    yravnenie += "1";
    yravnenie_output += "1";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_dwa_clicked()
{
    yravnenie += "2";
    yravnenie_output += "2";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_tri_clicked()
{
    yravnenie += "3";
    yravnenie_output += "3";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_cheture_clicked()
{
    yravnenie += "4";
    yravnenie_output += "4";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_pyat_clicked()
{
    yravnenie += "5";
    yravnenie_output += "5";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_six_clicked()
{
    yravnenie += "6";
    yravnenie_output += "6";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_cem_clicked()
{
    yravnenie += "7";
    yravnenie_output += "7";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_vosem_clicked()
{
    yravnenie += "8";
    yravnenie_output += "8";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_devyat_clicked()
{
    yravnenie += "9";
    yravnenie_output += "9";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_null_2_clicked()
{
    yravnenie += "0";
    yravnenie_output += "0";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_tochka_clicked()
{
    sps = yravnenie.split(" ");
    if (!sps[sps.length()-1].endsWith('.'))
    {
        yravnenie += ".";
        yravnenie_output += ".";
    }
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_plus_clicked()
{
    yravnenie += " + ";
    yravnenie_output += " + ";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_minus_clicked()
{
    yravnenie += " - ";
    yravnenie_output += " - ";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_ymnojit_clicked()
{
    yravnenie += " * ";
    yravnenie_output += " * ";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_delit_clicked()
{
    yravnenie += " / ";
    yravnenie_output += " / ";
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_plusMinus_clicked()
{
    yravnenie_output_sps = yravnenie_output.split(" ");
    sps = yravnenie.split(" ");
    if (sps[sps.length()-1].startsWith("-"))
    {
        sps[sps.length()-1] = sps[sps.length()-1].remove(0, 1);
        yravnenie_output_sps[yravnenie_output_sps.length()-1] = yravnenie_output_sps[yravnenie_output_sps.length()-1].remove(0, 1);;
    }
    else
    {
        sps[sps.length()-1] = "-" + sps[sps.length()-1];
        yravnenie_output_sps[yravnenie_output_sps.length()-1] = "-" + yravnenie_output_sps[yravnenie_output_sps.length()-1];
    }
    yravnenie = sps.join(" ");
    yravnenie_output = yravnenie_output_sps.join(" ");
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_clear_clicked()
{
    yravnenie.clear();
    yravnenie_output.clear();
    ui -> input -> setText(yravnenie_output);
    ui -> output -> setText(yravnenie_output);
}
void MainWindow::on_cos_clicked()
{
    yravnenie_output_sps = yravnenie_output.split(" ");
    sps = yravnenie.split(" ");
    if (sps[sps.length()-1][0] != '+' && sps[sps.length()-1][0] != '-' && sps[sps.length()-1][0] != '*' && sps[sps.length()-1][0] != '/')
    {
        sps.replace(sps.length()-1, QString::number(cos(sps[sps.length()-1].toDouble())));
    }
    yravnenie = sps.join(" ");
    yravnenie_output_sps.replace(yravnenie_output_sps.length()-1, "cos(" + yravnenie_output_sps[yravnenie_output_sps.length()-1] + ")");
    yravnenie_output = yravnenie_output_sps.join(" ");
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_lg_clicked()
{
    yravnenie_output_sps = yravnenie_output.split(" ");
    sps = yravnenie.split(" ");
    if (sps[sps.length()-1][0] != '+' && sps[sps.length()-1][0] != '-' && sps[sps.length()-1][0] != '*' && sps[sps.length()-1][0] != '/')
    {
        sps.replace(sps.length()-1, QString::number(log10(sps[sps.length()-1].toDouble())));
    }
    yravnenie = sps.join(" ");
    yravnenie_output_sps.replace(yravnenie_output_sps.length()-1, "lg(" + yravnenie_output_sps[yravnenie_output_sps.length()-1] + ")");
    yravnenie_output = yravnenie_output_sps.join(" ");
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_x2_clicked()
{
    yravnenie_output_sps = yravnenie_output.split(" ");
    sps = yravnenie.split(" ");
    if (sps[sps.length()-1][0] != '+' && sps[sps.length()-1][0] != '-' && sps[sps.length()-1][0] != '*' && sps[sps.length()-1][0] != '/')
    {
        sps.replace(sps.length()-1, QString::number(sps[sps.length()-1].toDouble() * sps[sps.length()-1].toDouble()));
    }
    yravnenie = sps.join(" ");
    yravnenie_output_sps.replace(yravnenie_output_sps.length()-1, yravnenie_output_sps[yravnenie_output_sps.length()-1] + QString::fromUtf8("²"));
    yravnenie_output = yravnenie_output_sps.join(" ");
    ui -> input -> setText(yravnenie_output);
}
void MainWindow::on_ymnojit_2_clicked()
{
    yravnenie_output_sps = yravnenie_output.split(" ");
    sps = yravnenie.split(" ");
    if (sps[sps.length()-1][0] != '+' && sps[sps.length()-1][0] != '-' && sps[sps.length()-1][0] != '*' && sps[sps.length()-1][0] != '/')
    {
        sps.replace(sps.length()-1, QString::number(sqrt(sps[sps.length()-1].toDouble())));
    }
    yravnenie_output_sps.replace(yravnenie_output_sps.length()-1, QString::fromUtf8("√") + yravnenie_output_sps[yravnenie_output_sps.length()-1]);
    yravnenie_output = yravnenie_output_sps.join(" ");
    yravnenie = sps.join(" ");
    ui -> input -> setText(yravnenie_output);
}

