#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:

    void on_odin_clicked();

    void on_dwa_clicked();

    void on_tri_clicked();

    void on_cheture_clicked();

    void on_pyat_clicked();

    void on_six_clicked();

    void on_cem_clicked();

    void on_vosem_clicked();

    void on_devyat_clicked();

    void on_null_2_clicked();

    void on_tochka_clicked();

    void on_plus_clicked();

    void on_minus_clicked();

    void on_ymnojit_clicked();

    void on_delit_clicked();

    void on_plusMinus_clicked();

    void on_clear_clicked();

    void on_cos_clicked();

    void on_lg_clicked();

    void on_x2_clicked();

    void on_ymnojit_2_clicked();

    void on_equals_clicked();

private:
    Ui::MainWindow *ui;
    void addToInput(const QString &input);
};

#endif // MAINWINDOW_H
