#include "novikova_bogacheva_lab1_var1_z1.h"
#include "ui_novikova_bogacheva_lab1_var1_z1.h"

novikova_bogacheva_lab1_var1_z1::novikova_bogacheva_lab1_var1_z1(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::novikova_bogacheva_lab1_var1_z1)
{
    ui->setupUi(this);
}

novikova_bogacheva_lab1_var1_z1::~novikova_bogacheva_lab1_var1_z1()
{
    delete ui;
}

QList <int> lst;
QString res;

void novikova_bogacheva_lab1_var1_z1::on_pushButton_clicked()
{
    if (ui -> checkBox -> isChecked())
    {
        res.clear();
        lst.clear();
        for (int i = 0; i < 5; i++)
        {
            int num = rand() % (100 - 1 + 1) + 1;
            lst.append(num);
        }
        for (int i = 0; i < lst.length(); i++)
        {
            res += QString::number(lst[i]) + " ";
        }
        ui -> label -> setText(res);
    }
    if (ui -> checkBox_2 -> isChecked())
    {
        res.clear();
        int num = rand() % (100 - 1 + 1) + 1;
        lst.append(num);
        for (int i = 0; i < lst.length(); i++)
        {
            res += QString::number(lst[i]) + " ";
        }
        ui -> label -> setText(res);
    }
    if (ui -> checkBox_3 -> isChecked())
    {
        res.clear();
        lst.removeLast();
        for (int i = 0; i < lst.length(); i++)
        {
            res += QString::number(lst[i]) + " ";
        }
        ui -> label -> setText(res);
    }
}

