#ifndef NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H
#define NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class novikova_bogacheva_lab1_var1_z1; }
QT_END_NAMESPACE

class novikova_bogacheva_lab1_var1_z1 : public QMainWindow
{
    Q_OBJECT

public:
    novikova_bogacheva_lab1_var1_z1(QWidget *parent = nullptr);
    ~novikova_bogacheva_lab1_var1_z1();

private slots:
    void on_pushButton_clicked();

private:
    Ui::novikova_bogacheva_lab1_var1_z1 *ui;
};
#endif // NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H

