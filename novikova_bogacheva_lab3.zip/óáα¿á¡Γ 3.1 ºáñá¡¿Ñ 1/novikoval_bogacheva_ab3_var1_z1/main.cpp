#include "novikova_bogacheva_lab1_var1_z1.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    novikova_bogacheva_lab1_var1_z1 w;
    w.show();
    return a.exec();
}
