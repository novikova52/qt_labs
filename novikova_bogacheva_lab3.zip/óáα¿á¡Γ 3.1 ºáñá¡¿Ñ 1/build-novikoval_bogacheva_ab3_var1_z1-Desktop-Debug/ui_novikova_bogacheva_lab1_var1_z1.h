/********************************************************************************
** Form generated from reading UI file 'novikova_bogacheva_lab1_var1_z1.ui'
**
** Created by: Qt User Interface Compiler version 4.8.7
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H
#define UI_NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QMainWindow>
#include <QtGui/QMenuBar>
#include <QtGui/QPushButton>
#include <QtGui/QStatusBar>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_novikova_bogacheva_lab1_var1_z1
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QLabel *label;
    QCheckBox *checkBox;
    QCheckBox *checkBox_2;
    QCheckBox *checkBox_3;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *novikova_bogacheva_lab1_var1_z1)
    {
        if (novikova_bogacheva_lab1_var1_z1->objectName().isEmpty())
            novikova_bogacheva_lab1_var1_z1->setObjectName(QString::fromUtf8("novikova_bogacheva_lab1_var1_z1"));
        novikova_bogacheva_lab1_var1_z1->resize(1210, 600);
        centralwidget = new QWidget(novikova_bogacheva_lab1_var1_z1);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        centralwidget->setMouseTracking(false);
        centralwidget->setAcceptDrops(false);
        centralwidget->setAutoFillBackground(false);
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(590, 180, 85, 33));
        label = new QLabel(centralwidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(430, 330, 391, 17));
        label->setAlignment(Qt::AlignCenter);
        checkBox = new QCheckBox(centralwidget);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(520, 230, 131, 21));
        checkBox_2 = new QCheckBox(centralwidget);
        checkBox_2->setObjectName(QString::fromUtf8("checkBox_2"));
        checkBox_2->setGeometry(QRect(520, 260, 261, 21));
        checkBox_3 = new QCheckBox(centralwidget);
        checkBox_3->setObjectName(QString::fromUtf8("checkBox_3"));
        checkBox_3->setGeometry(QRect(520, 290, 171, 21));
        novikova_bogacheva_lab1_var1_z1->setCentralWidget(centralwidget);
        menubar = new QMenuBar(novikova_bogacheva_lab1_var1_z1);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1210, 29));
        novikova_bogacheva_lab1_var1_z1->setMenuBar(menubar);
        statusbar = new QStatusBar(novikova_bogacheva_lab1_var1_z1);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        novikova_bogacheva_lab1_var1_z1->setStatusBar(statusbar);

        retranslateUi(novikova_bogacheva_lab1_var1_z1);

        QMetaObject::connectSlotsByName(novikova_bogacheva_lab1_var1_z1);
    } // setupUi

    void retranslateUi(QMainWindow *novikova_bogacheva_lab1_var1_z1)
    {
        novikova_bogacheva_lab1_var1_z1->setWindowTitle(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "novikova_bogacheva_lab1_var1_z1", 0, QApplication::UnicodeUTF8));
        pushButton->setText(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "\320\262\321\213\320\277\320\276\320\273\320\275\320\270\321\202\321\214", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "  \321\201\320\277\320\270\321\201\320\276\320\272", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "\321\201\320\276\320\267\320\264\320\260\321\202\321\214 \321\201\320\277\320\270\321\201\320\276\320\272", 0, QApplication::UnicodeUTF8));
        checkBox_2->setText(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "\320\264\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\200\320\260\320\275\320\264\320\276\320\274\320\275\320\276\320\265 \321\207\320\270\321\201\320\273\320\276 \320\262 \321\201\320\277\320\270\321\201\320\276\320\272", 0, QApplication::UnicodeUTF8));
        checkBox_3->setText(QApplication::translate("novikova_bogacheva_lab1_var1_z1", "\321\203\320\264\320\260\320\273\320\270\321\202\321\214 \321\207\320\270\321\201\320\273\320\276 \320\262 \320\272\320\276\320\275\321\206\320\265", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class novikova_bogacheva_lab1_var1_z1: public Ui_novikova_bogacheva_lab1_var1_z1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NOVIKOVA_BOGACHEVA_LAB1_VAR1_Z1_H
